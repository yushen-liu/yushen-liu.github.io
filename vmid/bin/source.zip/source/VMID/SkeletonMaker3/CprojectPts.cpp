#include "CprojectPts.h"

CprojectPts::CprojectPts(void)
{
}

CprojectPts::~CprojectPts(void)
{
}

void CprojectPts::SetValue(float f,Point3D pt)
{
	m_f=f;
	m_pt=pt;
}