//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by VolumeVisualizer.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_VolumeVisualizeTYPE         129
#define IDD_SAMPLE                      130
#define IDD_DIALOG1                     131
#define IDD_DIALOG_DISPLAYRESULTS       131
#define IDB_TOP                         133
#define IDB_BITMAP2                     134
#define IDB_TOPHOT                      134
#define IDB_TOPDISABLE                  135
#define IDD_DIALOG2                     136
#define IDD_DIALOG3                     137
#define IDC_CURSOR_ERASE                156
#define IDC_CURSOR_PENCIL               157
#define IDC_CURSOR_HAND                 159
#define IDC_CURSOR_PICK                 160
#define IDC_CURSOR_NOITEM               161
#define IDC_CURSOR_ROTATE               165
#define IDC_CURSOR_ZOOM                 166
#define IDC_CURSOR_MOVE                 167
#define IDR_TOOLBAR_TOOL                200
#define IDC_SAMPLE_NUM                  1000
#define IDC_ID_RANDOM                   1001
#define IDC_ID_UNIFORM                  1002
#define IDC_EDIT1                       1002
#define IDC_SPIN1                       1003
#define IDC_EDIT2                       1006
#define IDC_BUTTON_PREVIOUSPAGE         1045
#define IDC_BUTTON_NEXTPAGE             1046
#define IDC_BUTTON_CLOSE                1047
#define Display                         32771
#define ID                              32772
#define ID_GL_PS                        32773
#define ID_GL_SURFACE                   32774
#define ID_GL_POINTS                    32775
#define ID_GL_FULLPOINTS                32776
#define ID_GL_CELL                      32777
#define ID_ID_SAMPLE                    32778
#define ID_Menu                         32779
#define ID_GL_SAMPLEPOINTS              32780
#define ID_GL_CELL2                     32781
#define ID_ID_VISIUAL                   32782
#define ID_ID_VISIBILITY                32783
#define ID_GL_VISIBILITY                32784
#define ID_GL_MRC                       32785
#define ID_FILE_EXPORT                  32786
#define ID_ID_EXPORT                    32787
#define ID_ID_ED                        32788
#define ID_GL_TEXT                      32789
#define ID_GL_POINTS2                   32790
#define ID_GL_VISIBILITY2               32791
#define ID_RETRIEVE_IDRETRIEVE          32792
#define RETRIEVE_ID                     32793
#define ID_INFOR_ID_PRC                 32794
#define ID_INFOR_WEB                    32795
#define RETRIEVE_ED                     32796
#define RETRIEVE_GD                     32797
#define ID_OCTREE_SETOCTREE             32797
#define ID_OCTREE_SETOCTREE32798        32798
#define ID_DISPLAY_SHOWOCTREE           32799
#define ID_INNERDISTANCE_SETCOMPUTEVALUE 32800

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        138
#define _APS_NEXT_COMMAND_VALUE         32801
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
