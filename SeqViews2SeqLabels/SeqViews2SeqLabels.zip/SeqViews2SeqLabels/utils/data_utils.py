GO_ID = 0
def init_vocabulary(vocabulary_path):
    vocab = ""